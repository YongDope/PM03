﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PM3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button2.Visible = false;
        }


            
        private void button1_Click(object sender, EventArgs e)
        {
            Stream myStream;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((myStream = openFileDialog1.OpenFile())!=null)
                {
                    string stringfilename = openFileDialog1.FileName;
                    string filetext = File.ReadAllText(stringfilename);
                    richTextBox1.Text = filetext;
                    button2.Visible = true;
                 }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string st = richTextBox1.Text;
            textBox1.Text = st.Count(char.IsPunctuation).ToString();


            String[] ssslov = richTextBox1.Text.Split(' ', '\n');
            textBox2.Text = ssslov.Count().ToString();


            String[] sspredl = richTextBox1.Text.Split('.', '!', '?');
            int predl = sspredl.Count() - 1;
            textBox3.Text = predl.ToString();

            textBox4.Text = richTextBox1.Lines.Length.ToString();

            String[] ssabz = richTextBox1.Text.Split(new char[] {'\t'}, StringSplitOptions.RemoveEmptyEntries);
            textBox5.Text = ssabz.Length.ToString();
        }
    }
}
